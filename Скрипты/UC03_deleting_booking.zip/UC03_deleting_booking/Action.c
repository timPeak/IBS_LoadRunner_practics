﻿Action()
{
	lr_start_transaction("UC03_delete_booking");
	
	lr_start_transaction("open_webSite_WebTours");
	
	web_reg_find("Text=Welcome to the Web Tours site", LAST);
	
	web_url("index.htm", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("open_webSite_WebTours", LR_AUTO);
	
	lr_start_transaction("login_on_webSite");
	
	web_reg_find("Text=Web Tours Navigation Bar", LAST);
	
	web_url("nav.pl", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
    
    web_submit_form("login_on_webSite", 
        ITEMDATA,
        "Name=username", "Value={Name}", ENDITEM, 
		"Name=password", "Value={Pass}", ENDITEM, 
        LAST);
    
    web_url("in.home","url=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home",LAST); 
    
    web_reg_find("Text=Using the menu to the left", LAST);
    
    web_url("login.true", 
		"URL=http://localhost:1080/cgi-bin/login.pl?intro=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("login_on_webSite", LR_AUTO);

	lr_start_transaction("check_inventory");
	
	web_reg_find("Text=scheduled flights", LAST);
	
	web_reg_save_param_ex(
        "ParamName=bookId", 
        "LB/IC=\"flightID\" value=\"",
        "RB/IC=\"",
        "Ordinal=all",
        SEARCH_FILTERS,
        "Scope=body",
	    LAST);
	
	web_url("check.inventory", 
		"URL=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
    
    lr_end_transaction("check_inventory", LR_AUTO);
    
    lr_start_transaction("delete_booking");
    
    web_reg_find("Text=No flights have been reserved", LAST);
    
    web_submit_data("delete.booking",
        "Action=http://localhost:1080/cgi-bin/itinerary.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://localhost:1080/cgi-bin/itinerary.pl",
        "Snapshot=t4.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=flightID", "Value={bookId_1}",ENDITEM,
		"Name=removeAllFlights.x", "Value=63",ENDITEM, 
		"Name=removeAllFlights.y", "Value=9",ENDITEM, 
		"Name=.cgifields", "Value=1",ENDITEM, 
        LAST);
    
    lr_end_transaction("delete_booking", LR_AUTO);
    
    lr_start_transaction("sign_out");
    
    web_reg_find("Text=Welcome to the Web Tours site", LAST);

	web_url("sign.out", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
   
	lr_end_transaction("sign_out", LR_AUTO);
	
	lr_end_transaction("UC03_delete_booking", LR_AUTO);
	
	return 0;
}