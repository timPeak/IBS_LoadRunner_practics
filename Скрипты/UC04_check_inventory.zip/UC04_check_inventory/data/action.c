Action()
{

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("index.htm", 
		"URL=http://localhost:1080/webtours/index.htm", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"neifaoindggfcjicffkgpmnlppeffabd,ihnlcenocehgdaegdmhbidjhnhdchfmm,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,hnimpnehoodheedghdeeijklkeaacbdc,lmelglejhemejginpboagddgdfbepgmp,gcmjkmgdlgnkkcocmoeiminaijmmjnii,oimompecagnajdejgnnjijobebaeigek,obedbbhbpmojnkanicioggnmelmoomoc,laoigpblnllgcgjnjnllmfolckpjlhki,ehgidpndbllacpjalkiimkbadgjfnnmc,llkgjffcdpffmhiakmfcdcblohccpfmo,efniojlnjndmcbiieegkicadnoecjjef,imefjhfbkmcmebodilednhmaccmincoa,jflookgnkcckhobaglndicnbbgbonegd,"
		"ggkkehgbnfjpeggfpleeakpidbkibbmn,ojhpjlocmbogdgmfpkhlaaeamibhnphh,hfnkpimlhhgieaddgfemjhofmfblmnib,jamhcnnkihinmdlkakkaopbjbbcngflc,eeigpngbgcognadeebkilcpcaedhellh,gonpemdgkjcecdgbnaabipppbmgfggbe");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-112.0.5615.138");

	lr_think_time(28);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:5P2HT2pKbpV_9u0vV8pUBIf-QqVpQF2LdsEWANlNP_E&cup2hreq=43b68d1f51543afd26fd69bcd22cb13261003d9e45f1d01a6202554fa4feabbb", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohorthint\":\"Windows (102+, canary/dev/beta/stable)\",\"cohortname\":\"Windows (102+, canary/dev/beta/stable)\",\"enabled\":true,\"installdate\":5821,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.faef821457e35b44f92e45ae9c7c4424eb39c8f8bd02562a358bd2c5542570b9\"}]},\"ping\":{\"ping_freshness\":\""
		"{e64c8e5c-8817-4221-b2b2-aaadc7565a69}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"1.0.2512.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"cohorthint\":\"Win (Including up-to-date)\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{11e41a8a-5e22-4e74-aa6d-0bd3722d265a}\",\"rd\":5971},\"updatecheck\":{},\""
		"version\":\"1.3.36.141\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{81d6be7e-e07e-4a83-99c8-e01db3d06eac}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\""
		"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.4d4a9ece68f12d31fb4ebe458e7cbbce6bd27a5d363bce3344b1f4b5c6b024b4\"}]},\"ping\":{\"ping_freshness\":\"{a36c44d9-e3ac-4a40-994d-f7c7be7a476e}\",\"rd\":5971},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"58\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\""
		"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{3e4ed6a0-7a4a-445c-a09d-77f571fa096c}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp"
		"\":\"1.968de6b12bf23de49d6454d4819c028d080b9769dc2693e0bbb8a866c202d1ea\"}]},\"ping\":{\"ping_freshness\":\"{40b030b9-6d95-4b07-a4ad-6c5ee4763efd}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"390\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54AndUp\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.e66ec4166eb005622f590068730a0b2f19e608035a4428adb50fb236f84ac358\"}]},\"ping\":{\"ping_freshness\":\"{9493fea0-1ac4-4089-87a9-52efa014006f}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"9.44.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1bk9:\",\"cohorthint\":\"4.10.2557.0 for Chrome 95+\",\"cohortname\":\"4.10.2557.0 for Chrome 95+\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\""
		"{ada8f567-9815-4554-aae5-1adbb0ff63fc}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"4.10.2557.0\"},{\"accept_locale\":\"RU500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.b9e5d7ec90dfdb76759544b6635d08026e17ea96d341588ca3d99c2934c84112\"}]},\"ping\":{\"ping_freshness\":\"{759626a1-ba9f-41da-ace6-8b4d67b498a7}"
		"\",\"rd\":5971},\"updatecheck\":{},\"version\":\"20230410.524655861.1\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\"{dc8b88d2-b9ea-4cb4-8136-411b27bb32e7}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\""
		"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{ad102283-f4ee-4767-b4fc-0ee5adae8929}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":"
		"{\"package\":[{\"fp\":\"1.ab8d70a60ce0fba1355fad4edab88fd4d1bccc566b230998180183d1d776992b\"}]},\"ping\":{\"ping_freshness\":\"{52257210-4f8f-4c13-accd-c874137d7c1a}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"1.0.0.13\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohorthint\":\"Auto Stage3\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.e13a8882b7fc939bd0e4a1054a4d87867f70fc1fb82ae4edacc127b929dafaea\"}]},\"ping\":{\"ping_freshness\":\"{ab48e7f7-bbd5-4eec-9481-9775d5de489a}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"580\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GGLS\",\"cohort\":\"1:1iaf:\",\"cohorthint\":\"desktop_1_flatbuffer\",\"cohortname\":\"windows_flatbuffers\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.3525bd7c472e4c85cadf1b8d0992ca8303b9e630831e4530e54a14a70f213a11\"}]},\"ping\":{\"ping_freshness\":\"{3b4bb146-7d9f-4d94-8b9e-dedb5cba9bf4}\",\"rd\":5971},\"tag\":\"desktop_1_flatbuffer\",\"updatecheck\":{},\"version\":\"30.2\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.60ef116d2b56206e33698f79a6de1f1c3c00fa47ebbd5a5843d7299a2b2abfa8\"}]},\"ping\":{\"ping_freshness\":\"{7988a387-437c-41ba-83c4-c88f2254862a}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"2953\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:\",\"cohorthint\":\"108-and-above-all-users\",\"cohortname\":\"108-and-above-all-users\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{ab82f429-d27e-40af-b2b0-c388bc0f5975}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{8e692c53-de87-429d-bfa9-651f8fdc543a}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.374aaf23fe9cd5a7f2e0fd4da3768d2d28c7e79de2650b99d507725d20b7c4c7\"}]},\"ping"
		"\":{\"ping_freshness\":\"{78eb7863-ca99-401d-a643-199de689afdc}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"7979\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.49d709306bf5f0de51abfbfa3c546f8b3a42a942054014e5e0d12a3facc48b3b\"}]},\"ping\":{\"ping_freshness\":\"{17cbb6dd-791d-4b2f-93a0-57778a84122b}\",\"rd\""
		":5971},\"updatecheck\":{},\"version\":\"115.0.5758.0\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{5f851720-21b2-4dd1-aa13-5706e535effd}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\""
		"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohorthint\":\"General release\",\"cohortname\":\"General release\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.c51d23bc0653142853b0d9dc8ba00f504aaae8a2a5b290e539b8790d88c0dcbe\"}]},\"ping\":{\"ping_freshness\":\"{b219b658-9c87-46b9-8057-5e56a143e390}\",\"rd\":5971},\"updatecheck\":{},\"version\":\"2022.2.15.1\"}],\"arch"
		"\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":24,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.493\"},\"prodversion\":\"112.0.5615.138\",\"protocol\":\"3.1\",\"requestid\":\"{62701d64-fdda-4c0d-82d1-08f631f19f30}\",\"sessionid\":\"{c523e5bd-f16f-4914-9745-8167c93215e2}\",\"updater\":{\""
		"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.212\"},\"updaterversion\":\"112.0.5615.138\"}}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(11);

	web_url("header.html", 
		"URL=http://localhost:1080/webtours/header.html", 
		"Resource=0", 
		"Referer=http://localhost:1080/webtours/index.htm", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(6);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/webtours/index.htm", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("sign_in");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(104);

	web_submit_form("login.pl", 
		"Snapshot=t27.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo1", ENDITEM, 
		"Name=password", "Value=bean1", ENDITEM, 
		LAST);

	lr_start_transaction("click_on_Flights");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(97);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t28.inf", 
		LAST);

	lr_start_transaction("Find_flights_continue");

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(133);

	web_submit_form("reservations.pl", 
		"Snapshot=t29.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=05/10/2023", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=05/11/2023", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		LAST);

	lr_think_time(105);

	lr_start_transaction("Flight_departing_from_continue");

	web_submit_form("reservations.pl_2", 
		"Snapshot=t30.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=001;0;05/10/2023", ENDITEM, 
		"Name=reserveFlights.x", "Value=71", ENDITEM, 
		"Name=reserveFlights.y", "Value=13", ENDITEM, 
		LAST);

	lr_think_time(57);

	lr_start_transaction("1_transaction");

	web_submit_form("reservations.pl_3", 
		"Snapshot=t31.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Alex", ENDITEM, 
		"Name=lastName", "Value=Jason", ENDITEM, 
		"Name=address1", "Value=forest avenue", ENDITEM, 
		"Name=address2", "Value=87854", ENDITEM, 
		"Name=pass1", "Value=Alex Jason", ENDITEM, 
		"Name=creditCard", "Value=1111 2222 2222 2222", ENDITEM, 
		"Name=expDate", "Value=000", ENDITEM, 
		"Name=saveCC", "Value=on", ENDITEM, 
		LAST);

	lr_start_transaction("check_inventory");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	lr_think_time(51);

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t32.inf", 
		LAST);

	lr_start_transaction("sign_out");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(58);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t33.inf", 
		LAST);

	return 0;
}