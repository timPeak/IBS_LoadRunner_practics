﻿Action()
{
	lr_start_transaction("UC02_ticket_booking");
	
	lr_start_transaction("open_webSite_WebTours");
	
	web_reg_find("Text=Welcome to the Web Tours site", LAST);
	
	web_url("index.htm", 
		"URL=http://localhost:1080/webtours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("open_webSite_WebTours", LR_AUTO);
	
	lr_start_transaction("login_on_webSite");
	
	web_reg_find("Text=Web Tours Navigation Bar", LAST);
	
	web_url("nav.pl", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
    
    web_submit_form("login_on_webSite", 
        ITEMDATA,
        "Name=username", "Value={Name}", ENDITEM, 
		"Name=password", "Value={Pass}", ENDITEM, 
        LAST);
	
	web_submit_data("login_on_webSite_session",
        "Action=http://localhost:1080/cgi-bin/login.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://localhost:1080/cgi-bin/login.pl",
        "Snapshot=t4.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=userSession", "Value={SessionId}.844633455HAVfiAQpicAiDDDDtcAQtpifiQcf",ENDITEM,
		"Name=username", "Value={Name}",ENDITEM, 
		"Name=password", "Value={Pass}",ENDITEM, 
		"Name=login.x", "Value=55",ENDITEM, 
		"Name=login.y", "Value=8",ENDITEM, 
		"Name=JSFormSubmit", "Value=off",ENDITEM, 
        LAST );
    
    web_url("in.home","url=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home",LAST); 
    
    web_reg_find("Text=Using the menu to the left", LAST);
    
    //Проверка входа на сайт
    
    web_url("login.true", 
		"URL=http://localhost:1080/cgi-bin/login.pl?intro=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("login_on_webSite", LR_AUTO);

	lr_start_transaction("Find_flights");
	
	web_reg_save_param_ex(
        "ParamName=BlueSkyNumb", 
        "LB/IC=\"outboundFlight\" value=\"",
        "RB/IC=;",
        "Ordinal=all",
        SEARCH_FILTERS,
        "Scope=body",
	    LAST);
	
	web_reg_save_param_ex(
        "ParamName=BlueSkyCost", 
        "LB/IC=$ ",
        "RB/IC=<",
        "Ordinal=all",
        SEARCH_FILTERS,
        "Scope=body",
	    LAST);
	
	web_reg_find("Text=Blue Sky Air", LAST);
	
	web_submit_data("reservations.pl",
        "Action=http://localhost:1080/cgi-bin/reservations.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://localhost:1080/cgi-bin/reservations.pl",
        "Snapshot=t4.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=advanceDiscount", "Value=0",ENDITEM,
		"Name=depart", "Value={City}",ENDITEM, 
		"Name=departDate", "Value={dateStart}",ENDITEM, 
		"Name=arrive", "Value={City_back}",ENDITEM, 
		"Name=returnDate", "Value={dateEnd}",ENDITEM, 
		"Name=numPassengers", "Value=1",ENDITEM, 
		"Name=seatPref", "Value={Plase}",ENDITEM,
        "Name=seatType", "Value={Bclass}",ENDITEM,		
		"Name=findFlights.x","Value=71",ENDITEM,
        "Name=findFlights.y","Value=12",ENDITEM,
        "Name=.cgifields","Value=roundtrip",ENDITEM,
        "Name=.cgifields","Value=seatType",ENDITEM,
        "Name=.cgifields","Value=seatPref",ENDITEM,
        LAST );
	
	lr_end_transaction("Find_flights", LR_AUTO);

	lr_start_transaction("Flight_departing_from");
	
	web_reg_find("Text=buyFlights", LAST);
	
	web_submit_data("reservations.pl_2",
        "Action=http://localhost:1080/cgi-bin/reservations.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://localhost:1080/cgi-bin/reservations.pl",
        "Snapshot=t51.inf",
        "Mode=HTML",
        ITEMDATA,
		"Name=outboundFlight", "Value={BlueSkyNumb_1};{BlueSkyCost_1};{dateStart}",ENDITEM,
        "Name=numPassengers","Value=1",ENDITEM,
        "Name=advanceDiscount","Value=0",ENDITEM,
        "Name=seatType","Value={Plase}",ENDITEM,
        "Name=seatPref","Value={Bclass}",ENDITEM,
		"Name=reserveFlights.x", "Value=71",ENDITEM, 
		"Name=reserveFlights.y", "Value=13",ENDITEM,
        LAST);
	
	lr_end_transaction("Flight_departing_from", LR_AUTO);

	lr_start_transaction("Payment_Details");
	
	web_reg_find("Text=Thank you for booking through Web Tours", LAST);

	web_submit_data("reservations.pl_3",
	    "Action=http://localhost:1080/cgi-bin/reservations.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://localhost:1080/cgi-bin/reservations.pl",
        "Snapshot=t6.inf",
        "Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value={UserName}", ENDITEM, 
		"Name=lastName", "Value={UserLastName}", ENDITEM, 
		"Name=address1", "Value={Street}", ENDITEM, 
		"Name=address2", "Value={Zipcode}", ENDITEM, 
		"Name=pass1", "Value={UserName} {UserLastName}", ENDITEM, 
		"Name=creditCard", "Value={CreditCard}", ENDITEM, 
		"Name=expDate", "Value={CVV}", ENDITEM, 
		"Name=saveCC", "Value=on", ENDITEM,
        "Name=oldCCOption","Value=",ENDITEM,
        "Name=numPassengers","Value=1",ENDITEM,
        "Name=seatType","Value=Coach",ENDITEM,
        "Name=seatPref","Value=None",ENDITEM,
        "Name=outboundFlight","Value={BlueSkyNumb_1};{BlueSkyCost_1};{dateStart}",ENDITEM,
        "Name=advanceDiscount","Value=0",ENDITEM,
        "Name=returnFlight","Value=",ENDITEM,
        "Name=JSFormSubmit","Value=off",ENDITEM,
        "Name=buyFlights.x","Value=70",ENDITEM,
        "Name=buyFlights.y","Value=8",ENDITEM,
        "Name=.cgifields","Value=saveCC",ENDITEM,		
		LAST);
	
	lr_end_transaction("Payment_Details", LR_AUTO);

	lr_start_transaction("check_inventory");
	
	web_reg_find("Text=Flight #1", LAST);
	
	web_url("check.inventory", 
		"URL=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
    
    lr_end_transaction("check_inventory", LR_AUTO);
    
    lr_start_transaction("sign_out");
    
    web_reg_find("Text=navbar", LAST);

	web_url("sign.out", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
   
	lr_end_transaction("sign_out", LR_AUTO);
	
	lr_end_transaction("UC02_ticket_booking", LR_AUTO);
	
	return 0;
}