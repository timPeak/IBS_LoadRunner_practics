Action()
{

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("index.htm", 
		"URL=http://localhost:1080/webtours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("X-Goog-Update-AppId", 
		"neifaoindggfcjicffkgpmnlppeffabd,ihnlcenocehgdaegdmhbidjhnhdchfmm,obedbbhbpmojnkanicioggnmelmoomoc,hnimpnehoodheedghdeeijklkeaacbdc,gcmjkmgdlgnkkcocmoeiminaijmmjnii,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,hfnkpimlhhgieaddgfemjhofmfblmnib,oimompecagnajdejgnnjijobebaeigek,llkgjffcdpffmhiakmfcdcblohccpfmo,laoigpblnllgcgjnjnllmfolckpjlhki,lmelglejhemejginpboagddgdfbepgmp,efniojlnjndmcbiieegkicadnoecjjef,jflookgnkcckhobaglndicnbbgbonegd,ehgidpndbllacpjalkiimkbadgjfnnmc,"
		"jamhcnnkihinmdlkakkaopbjbbcngflc,ggkkehgbnfjpeggfpleeakpidbkibbmn,imefjhfbkmcmebodilednhmaccmincoa,ojhpjlocmbogdgmfpkhlaaeamibhnphh,eeigpngbgcognadeebkilcpcaedhellh,gonpemdgkjcecdgbnaabipppbmgfggbe");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-112.0.5615.138");

	lr_think_time(13);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:0KPWcm3aL9IqYnELakabfgMTWu46_LtKPHcBcEROElE&cup2hreq=aff07a9021abbd9a823c0c11747237f24a16684d39ad2399411735f0c728bf5c", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohorthint\":\"Windows (102+, canary/dev/beta/stable)\",\"cohortname\":\"Windows (102+, canary/dev/beta/stable)\",\"enabled\":true,\"installdate\":5821,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.faef821457e35b44f92e45ae9c7c4424eb39c8f8bd02562a358bd2c5542570b9\"}]},\"ping\":{\"ping_freshness\":\""
		"{e85e4bd2-ab9d-4f91-8890-f79b5e340a33}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"1.0.2512.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"cohorthint\":\"Win (Including up-to-date)\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{58f576f3-25ff-4aa8-a3c1-5650abcb1a56}\",\"rd\":5970},\"updatecheck\":{},\""
		"version\":\"1.3.36.141\"},{\"accept_locale\":\"RU500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.b9e5d7ec90dfdb76759544b6635d08026e17ea96d341588ca3d99c2934c84112\"}]},\"ping\":{\"ping_freshness\":\"{04d5620b-7e93-453d-93b7-52282cc56875}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"20230410.524655861.1\"},{\""
		"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{34760f2c-6edb-4977-83a7-0e4cc36a2428}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54AndUp\",\""
		"cohortname\":\"M54AndUp\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.e66ec4166eb005622f590068730a0b2f19e608035a4428adb50fb236f84ac358\"}]},\"ping\":{\"ping_freshness\":\"{b6093532-3283-4bc0-9a0b-e1637c4ca613}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"9.44.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":"
		"\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{31c9a53a-c51a-4935-915a-5413aba410cd}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.4d4a9ece68f12d31fb4ebe458e7cbbce6bd27a5d363bce3344b1f4b5c6b024b4\"}]},\"ping\":{\"ping_freshness\":\"{75e63df3-2295-4e21-b86a-2246a4177e8f}\",\"rd\":5970},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"58\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.1e2ede36a5cb082c56ea2316b13db135a332e64bdaea400d3bf854518ec3ab29\"}]},\"ping\":{\"ping_freshness\":\"{ac490dbf-3bee-419c-89f6-e99ccc52ec12}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"7977\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1bk9:\",\"cohorthint\":\"4.10.2557.0 for Chrome 95+\",\"cohortname\":\"4.10.2557.0 for Chrome 95+\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\"{f67a6bb0-a84e-417f-b677-2952703e1944"
		"}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"4.10.2557.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.ab8d70a60ce0fba1355fad4edab88fd4d1bccc566b230998180183d1d776992b\"}]},\"ping\":{\"ping_freshness\":\"{1fe39570-2bbe-4396-bb0b-0cde5de1f286}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"1.0.0.13\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\""
		":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"ping\":{\"ping_freshness\":\"{e438385b-6a86-482f-8631-ce713b8cc2cc}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.968de6b12bf23de49d6454d4819c028d080b9769dc2693e0bbb8a866c202d1ea\"}]},\"ping\":{\"ping_freshness\":\"{cea25f86-1cf2-43ff-8511-ae4e27ecbee7}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"390\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohorthint\":\"Auto Stage3\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\""
		"1.e13a8882b7fc939bd0e4a1054a4d87867f70fc1fb82ae4edacc127b929dafaea\"}]},\"ping\":{\"ping_freshness\":\"{26636abb-f2a2-4170-93a0-01c8ef5ac559}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"580\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.60ef116d2b56206e33698f79a6de1f1c3c00fa47ebbd5a5843d7299a2b2abfa8\"}]},\""
		"ping\":{\"ping_freshness\":\"{77491666-9aba-4176-9271-2a9bf4053600}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"2953\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{1f48bcda-c879-486b-98b1-6a818cd0d9c8}"
		"\",\"rd\":5970},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.985b104f7925fc9454949f142ad0249fe52ce43d65bf5c4a614c3b0b9bc532dd\"}]},\"ping\":{\"ping_freshness\":\"{c4554ad2-5aa2-4608-81b3-e7f39bcfc098}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"115.0.5756.0\"},{\""
		"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:\",\"cohorthint\":\"108-and-above-all-users\",\"cohortname\":\"108-and-above-all-users\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{497cc16b-b0d6-423c-9eed-86582799dda2}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\""
		"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GGLS\",\"cohort\":\"1:1iaf:\",\"cohorthint\":\"desktop_1_flatbuffer\",\"cohortname\":\"windows_flatbuffers\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.3525bd7c472e4c85cadf1b8d0992ca8303b9e630831e4530e54a14a70f213a11\"}]},\"ping\":{\"ping_freshness\":\"{01cc5dd3-68d6-42c5-8827-856502f56a6b}\",\"rd\":5970},\"tag\":\"desktop_1_flatbuffer\",\"updatecheck\":{},\"version\":\"30.2\"},{\"appid\":\""
		"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{96791c3b-9fe3-4d5d-96a4-eef45a526063}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:"
		"\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{10b696fd-f60c-4662-9713-ec7e43268a7f}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohorthint\":\""
		"General release\",\"cohortname\":\"General release\",\"enabled\":true,\"installdate\":5769,\"lang\":\"ru\",\"packages\":{\"package\":[{\"fp\":\"1.c51d23bc0653142853b0d9dc8ba00f504aaae8a2a5b290e539b8790d88c0dcbe\"}]},\"ping\":{\"ping_freshness\":\"{55a5dd94-8ee5-4226-96b5-fe5e40e6c017}\",\"rd\":5970},\"updatecheck\":{},\"version\":\"2022.2.15.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":24,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,"
		"\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.493\"},\"prodversion\":\"112.0.5615.138\",\"protocol\":\"3.1\",\"requestid\":\"{f199e981-1155-4687-b9e5-b8c1d9347953}\",\"sessionid\":\"{ed1626c1-2981-4558-bb8b-d06c61b5faa9}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.212\"},\""
		"updaterversion\":\"112.0.5615.138\"}}", 
		LAST);

	lr_start_transaction("1_transaction");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("login.pl", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/home.html", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("UC2_register");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(97);

	web_submit_form("login.pl_2", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo10", ENDITEM, 
		"Name=password", "Value=jojo10", ENDITEM, 
		"Name=passwordConfirm", "Value=jojo10", ENDITEM, 
		"Name=firstName", "Value=John", ENDITEM, 
		"Name=lastName", "Value=Peters", ENDITEM, 
		"Name=address1", "Value=cats street", ENDITEM, 
		"Name=address2", "Value=787578", ENDITEM, 
		"Name=register.x", "Value=59", ENDITEM, 
		"Name=register.y", "Value=5", ENDITEM, 
		LAST);

	lr_start_transaction("2_transaction");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(19);

	web_image("button_next.gif", 
		"Src=/WebTours/images/button_next.gif", 
		"Snapshot=t6.inf", 
		LAST);

	lr_start_transaction("4");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(42);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t7.inf", 
		LAST);

	return 0;
}