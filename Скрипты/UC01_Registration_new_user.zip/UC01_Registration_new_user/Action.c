﻿Action()
{
	lr_start_transaction("UC01_Registration_new_user");
	
	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	
	lr_start_transaction("open_webSite_WebTours");
	
	web_reg_find("Text=Web Tour", LAST);

	web_url("index.htm", 
		"URL=http://localhost:1080/webtours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("open_webSite_WebTours", LR_AUTO);

	lr_start_transaction("click_sign_up");
	
	web_reg_find("Text=Please complete the form below", LAST);
	
	web_url("sign.on", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("click_sign_up", LR_AUTO);
	
	lr_start_transaction("writing_fields");
	
	web_reg_find("Text=Click below when you're ready to plan your dream trip", LAST);
	
    web_submit_data("login.pl_2",
        "Action=http://localhost:1080/cgi-bin/login.pl",
        "Method=POST",
        "TargetFrame=",
        "RecContentType=text/html",
        "Referer=http://127.0.0.1:1080/WebTours/login.pl?username=&password=&getInfo=true",
        "Snapshot=t7.inf",
        "Mode=HTML",
        ITEMDATA,
        "Name=username", "Value={Log}", ENDITEM, 
		"Name=password", "Value={Pass}", ENDITEM, 
		"Name=passwordConfirm", "Value={Pass}", ENDITEM, 
		"Name=firstName", "Value={FirstName}", ENDITEM, 
		"Name=lastName", "Value={LastName}", ENDITEM, 
		"Name=address1", "Value={Street}", ENDITEM, 
		"Name=address2", "Value={Zipcode}", ENDITEM, 
		"Name=register.x", "Value=59", ENDITEM, 
		"Name=register.y", "Value=5", ENDITEM, 
        LAST );
	
	lr_end_transaction("writing_fields", LR_AUTO);
	
	lr_start_transaction("sign_off");
	
	web_reg_find("Text=Welcome to the Web Tours site", LAST);
	
	web_url("sign.out", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("sign_off", LR_AUTO);
	
	lr_end_transaction("UC01_Registration_new_user", LR_AUTO);

	return 0;
}