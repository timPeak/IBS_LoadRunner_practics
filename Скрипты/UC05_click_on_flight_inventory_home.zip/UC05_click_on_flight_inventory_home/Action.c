﻿Action()
{
	lr_start_transaction("UC05_click_on_flight_inventory_home");
	
	lr_start_transaction("open_webSite_WebTours");
	
	web_reg_find("Text=Welcome to the Web Tours site", LAST);
	
	web_url("index.htm", 
		"URL=http://localhost:1080/WebTours/home.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("open_webSite_WebTours", LR_AUTO);
	
	lr_start_transaction("login_on_webSite");
	
	web_reg_find("Text=Web Tours Navigation Bar", LAST);
	
	web_url("nav.pl", 
		"URL=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
    
    web_submit_form("login_on_webSite", 
        ITEMDATA,
        "Name=username", "Value={Name}", ENDITEM, 
		"Name=password", "Value={Pass}", ENDITEM, 
        LAST);
    
    web_url("in.home","url=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home",LAST); 
    
    web_reg_find("Text=Using the menu to the left", LAST);
    
    web_url("login.true", 
		"URL=http://localhost:1080/cgi-bin/login.pl?intro=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("login_on_webSite", LR_AUTO);
	
	lr_start_transaction("click_on_flight");
	
	web_reg_find("Text=Find Flight", LAST);
	
	web_url("click_on_flight", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
    
    lr_end_transaction("click_on_flight", LR_AUTO);

	lr_start_transaction("click_on_inventory");
	
	web_reg_find("Text=Itinerary", LAST);
	
	web_url("click_on_inventory", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
    
    lr_end_transaction("click_on_inventory", LR_AUTO);
    
    lr_start_transaction("click_on_home");
	
	web_reg_find("Text=Web Tours reservation pages", LAST);
	
	web_url("click_on_home", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
    
    lr_end_transaction("click_on_home", LR_AUTO);
    
    lr_start_transaction("sign_out");
    
    web_reg_find("Text=Welcome to the Web Tours site", LAST);

	web_url("sign.out", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
   
	lr_end_transaction("sign_out", LR_AUTO);
	
	lr_end_transaction("UC05_click_on_flight_inventory_home", LR_AUTO);
	
	return 0;
}